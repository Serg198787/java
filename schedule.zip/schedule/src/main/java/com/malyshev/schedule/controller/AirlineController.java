package com.malyshev.schedule.controller;

import com.malyshev.schedule.entity.AirlineEntity;
import com.malyshev.schedule.service.AirlineService;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AirlineController {

    @Autowired
    AirlineService airlineService;

    @GetMapping("/")
    public String getAirlines(Model model) {
        ArrayList<AirlineEntity> airlines = airlineService.getAllAirlines();
        model.addAttribute("airlines", airlines);
        return "airlines";
    }

}
