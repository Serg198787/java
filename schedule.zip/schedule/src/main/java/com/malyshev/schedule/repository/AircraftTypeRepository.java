package com.malyshev.schedule.repository;

import com.malyshev.schedule.entity.AircraftTypeEntity;
import org.springframework.data.repository.CrudRepository;

public interface AircraftTypeRepository extends CrudRepository<AircraftTypeEntity, Long> {

}
