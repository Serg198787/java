package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.AircraftTypeEntity;
import com.malyshev.schedule.repository.AircraftTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AircraftTypeService {

    @Autowired
    AircraftTypeRepository repository;

    public void createAircraftType(AircraftTypeEntity aircraft) {
        repository.save(aircraft);
    }

    public AircraftTypeEntity getTypeById(Long id) {
        return repository.findById(id).orElseThrow();
    }

    public void updateTypeName(Long id, String type) {
        AircraftTypeEntity aircraftType = repository.findById(id).orElseThrow();
        aircraftType.setType(type);
        repository.save(aircraftType);
    }

    public void deleteAircraftType(Long id) {
        repository.deleteById(id);

    }

}
