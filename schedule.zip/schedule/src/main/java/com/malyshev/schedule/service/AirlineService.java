package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.AirlineEntity;
import com.malyshev.schedule.repository.AirlineRepository;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AirlineService {

    @Autowired
    AirlineRepository repository;

    public void createAirline(AirlineEntity airline) {
        repository.save(airline);
    }

    public ArrayList<AirlineEntity> getAllAirlines() {
        ArrayList<AirlineEntity> airlines = new ArrayList<>();
        Iterable<AirlineEntity> airlineFromDb = repository.findAll();
        airlineFromDb.forEach(e -> airlines.add(e));
        return airlines;
    }

    public AirlineEntity getAirlineById(Long id) {
        return repository.findById(id).orElseThrow();
    }

    public void updateAirlineName(Long id, String name) {
        AirlineEntity airlane = repository.findById(id).orElseThrow();
        airlane.setName(name);
        repository.save(airlane);
    }

    public void deleteAirline(Long id) {
        repository.deleteById(id);

    }

}
