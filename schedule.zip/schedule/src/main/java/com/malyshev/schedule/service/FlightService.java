package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.FlightEntity;
import com.malyshev.schedule.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FlightService {

    @Autowired
    FlightRepository repository;

    public void createFlight(FlightEntity flight) {
        repository.save(flight);
    }

    public FlightEntity getFlightById(Long id) {
        return repository.findById(id).orElseThrow();
    }

    public void updateFlightNumber(Long id, int number) {
        FlightEntity flight = repository.findById(id).orElseThrow();
        flight.setFlightNumber(number);
        repository.save(flight);
    }

    public void deleteFlight(Long id) {
        repository.deleteById(id);

    }

}
