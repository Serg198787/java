package com.malyshev.schedule.repository;

import com.malyshev.schedule.entity.AirlineEntity;
import org.springframework.data.repository.CrudRepository;

public interface AirlineRepository extends CrudRepository<AirlineEntity, Long> {

}
