package com.malyshev.schedule.repository;

import com.malyshev.schedule.entity.FlightEntity;
import org.springframework.data.repository.CrudRepository;

public interface FlightRepository extends CrudRepository<FlightEntity, Long> {

}
