package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.FlightEntity;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FlightServiceTest {

    @Autowired
    FlightService flightService;

    public FlightServiceTest() {
    }

    @Test
    public void testCreateFlight() {
        System.out.println("createAirline");
        FlightEntity flight = new FlightEntity();
        flight.setFlightNumber(1);
        flightService.createFlight(flight);
        assertNotNull(flight);
        fail("The test case is a prototype.");
    }

    @Test
    public void testGetFlightById() {
        System.out.println("getFlightById");
        Long id = Long.valueOf(1);
        FlightEntity flight = flightService.getFlightById(id);
        assertEquals(id, flight.getId());
        assertEquals(1, flight.getFlightNumber());
        fail("The test case is a prototype.");
    }

    @Test
    public void testUpdateFlightNumber() {
        System.out.println("updateFlightNumber");
        Long id = Long.valueOf(1);
        int num = 2;
        flightService.updateFlightNumber(id, num);
        FlightEntity flight = flightService.getFlightById(id);
        assertEquals(num, flight.getFlightNumber());
        fail("The test case is a prototype.");
    }

    @Test
    public void testDeleteFlight() {
        System.out.println("deleteFlight");
        Long id = Long.valueOf(1);
        flightService.deleteFlight(id);
        FlightEntity flight = null;
        try {
            flight = flightService.getFlightById(id);
        } catch (NoSuchElementException e) {
            assertNull(flight);
        }
        fail("The test case is a prototype.");
    }

}
