package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.AirlineEntity;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AirlineServiceTest {

    @Autowired
    AirlineService airlineService;

    public AirlineServiceTest() {
    }

    @Test
    public void testCreateAirline() {
        System.out.println("createAirline");
        AirlineEntity airline = new AirlineEntity();
        airline.setName("Рощино");
        airlineService.createAirline(airline);
        assertNotNull(airline);
        fail("The test case is a prototype.");
    }

    @Test
    public void testGetAirlineById() {
        System.out.println("getAirlineById");
        Long id = Long.valueOf(1);
        AirlineEntity airline = airlineService.getAirlineById(id);
        assertEquals(id, airline.getId());
        assertEquals("Рощино", airline.getName());
        fail("The test case is a prototype.");
    }

    @Test
    public void testUpdateAirlineName() {
        System.out.println("updateAirlineName");
        Long id = Long.valueOf(1);
        String name = "Авиа-Сибирь";
        airlineService.updateAirlineName(id, name);
        AirlineEntity airline = airlineService.getAirlineById(id);
        assertEquals(airline.getName(), name);
        fail("The test case is a prototype.");
    }

    @Test
    public void testDeleteAirline() {
        System.out.println("deleteAirline");
        Long id = Long.valueOf(1);
        airlineService.deleteAirline(id);
        AirlineEntity airline = null;
        try {
            airlineService.getAirlineById(id);
        } catch (NoSuchElementException e) {
            assertNull(airline);
        }
        fail("The test case is a prototype.");
    }

    @Test
    public void testGetAllAirlines() {
        System.out.println("getAllAirlines");
        String[] names = {"АЭРОПЛАН", "Владимирская авиабаза", "КузбассАвиа"};
        AirlineEntity airline1 = new AirlineEntity();
        airline1.setName(names[0]);
        AirlineEntity airline2 = new AirlineEntity();
        airline2.setName(names[1]);
        AirlineEntity airline3 = new AirlineEntity();
        airline3.setName(names[2]);
        airlineService.createAirline(airline1);
        airlineService.createAirline(airline2);
        airlineService.createAirline(airline3);
        ArrayList<AirlineEntity> airlines = airlineService.getAllAirlines();
        assertEquals(3, airlines.size());
        fail("The test case is a prototype.");
    }

}
