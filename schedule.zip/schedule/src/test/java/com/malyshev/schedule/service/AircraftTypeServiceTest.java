package com.malyshev.schedule.service;

import com.malyshev.schedule.entity.AircraftTypeEntity;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AircraftTypeServiceTest {

    @Autowired
    AircraftTypeService aircraftTypeService;

    public AircraftTypeServiceTest() {
    }

    @Test
    public void testCreateAircraftType() {
        System.out.println("createAircraftType");
        AircraftTypeEntity aircraft = new AircraftTypeEntity();
        aircraft.setType("Аэростат");
        aircraftTypeService.createAircraftType(aircraft);
        assertNotNull(aircraft);
        fail("The test case is a prototype.");
    }

    @Test
    public void testGetTypeById() {
        System.out.println("getTypeById");
        Long id = Long.valueOf(1);
        AircraftTypeEntity type = aircraftTypeService.getTypeById(id);
        assertEquals(id, type.getId());
        assertEquals("Аэростат", type.getType());
        fail("The test case is a prototype.");
    }

    @Test
    public void testUpdateTypeName() {
        System.out.println("updateTypeName");
        Long id = Long.valueOf(1);
        String type = "Дирижабль";
        aircraftTypeService.updateTypeName(id, type);
        AircraftTypeEntity airType = aircraftTypeService.getTypeById(id);
        assertEquals(type, airType.getType());
        fail("The test case is a prototype.");
    }

    @Test
    public void testDeleteAircraftType() {
        System.out.println("deleteAircraftType");
        Long id = Long.valueOf(1);
        aircraftTypeService.deleteAircraftType(id);
        AircraftTypeEntity type = null;
        try {
            type = aircraftTypeService.getTypeById(id);
        } catch (NoSuchElementException e) {
            assertNull(type);
        }
        fail("The test case is a prototype.");
    }

}
